var run_data={
    "duration":"0h29m50s",
    "end_time":"27/01/2024 17:16:48",
    "input":{
        "accession":[
            {
                "id":"genome_0",
                "label":"Pyrococcus horikoshii OT3"
            },
            {
                "id":"genome_1",
                "label":"Candidatus Prometheoarchaeum syntrophicum"
            }
        ],
        "accession_newick":[],
        "bgc":[
            {
                "acc":0,
                "class":0,
                "id":"GCF_000011105.1"
            },
            {
                "acc":1,
                "class":1,
                "id":"GCF_008000775.1"
            }
        ],
        "classes":[
            {
                "label":"RiPPs"
            },
            {
                "label":"Others"
            }
        ]
    },
    "networks":[],
    "parameters":"--inputdir input --outputdir result --include_gbk_str G --pfam_dir pfam --core 1 --min_bgc_size 0 --cutoffs 0.3 --mode glocal",
    "start_time":"27/01/2024 16:46:58"
};
dataLoaded();
