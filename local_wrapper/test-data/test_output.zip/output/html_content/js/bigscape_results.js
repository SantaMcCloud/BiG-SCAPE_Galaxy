var bigscape_results = [
    {
        "label":"2024-01-27_16-46-58_hybrids_glocal_c0.30",
        "networks":[]
    }
];